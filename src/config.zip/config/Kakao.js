const KakaoKey = "39f19acb55befaf9d13d5ccd62749ebd"


export default KakaoKey