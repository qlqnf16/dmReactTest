import firebase from 'firebase'

const config = {
    apiKey: "AIzaSyCoxQQzVeunCxWU9vwxyubKqO8R5SQ5TD8",
    authDomain: "react-6b228.firebaseapp.com",
    databaseURL: "https://react-6b228.firebaseio.com",
    projectId: "react-6b228",
    storageBucket: "react-6b228.appspot.com",
    messagingSenderId: "517873004982"
};

const fire = firebase.initializeApp(config);
export default fire;
export const uiConfig = {
    signInFlow: 'popup',
    signInOptions : [
        firebase.auth.FacebookAuthProvider.PROVIDER_ID,
        firebase.auth.GoogleAuthProvider.PROVIDER_ID
    ],
    callbacks: {
        signInSuccessWithAuthResult: () => {
            const currentUser = firebase.auth().currentUser
            const userData = {
                name : currentUser.displayName,
                age : null,
                uid : currentUser.uid,
                email : currentUser.email
            }
            firebase.database().ref('users/' + currentUser.uid).set(userData)
            console.log("callback")
            console.log(this)
        }
    }
}